﻿//////////////////////////////////////////////////////////////////////////
// Copyright 2001-2014 Aspose Pty Ltd. All Rights Reserved.
//
// This file is part of Aspose.Words. The source code in this file
// is only intended as a supplement to the documentation, and is provided
// "as is", without warranty of any kind, either expressed or implied.
//////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;

namespace CSharp.LINQ
{
    public class Contract
    {
        public Contract(Client client, float price, DateTime date)
        {            
            _client = client;
            _price = price;
            _date = date;
        }
        public Manager Manager { get { return _manager; } set { _manager = value; } }
        public Client Client { get { return _client; } }
        public float Price { get { return _price; } }
        public DateTime Date { get { return _date; } }
        private DateTime _date;
        private float _price;
        private Manager _manager;
        private Client _client;
    }
    public class Contracts : List<Contract>
    {

    }    
}
