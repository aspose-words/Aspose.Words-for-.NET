﻿//////////////////////////////////////////////////////////////////////////
// Copyright 2001-2014 Aspose Pty Ltd. All Rights Reserved.
//
// This file is part of Aspose.Words. The source code in this file
// is only intended as a supplement to the documentation, and is provided
// "as is", without warranty of any kind, either expressed or implied.
//////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Aspose.Words;
using Aspose.Words.Reporting;

namespace CSharp.LINQ
{
    class BubbleChart
    {
        public static void Run()
        {
            // The path to the documents directory.
            string dataDir = RunExamples.GetDataDir_LINQ(); 

            // Load the template document.
            Document doc = new Document(dataDir + "BubbleChart.docx");

            // Call Common class Contracts method to set Contracts which is basically an enumeration of instances of Contract class. 
            Contracts contracts = Common.Contracts();
            
            // Create a Reporting Engine.
            ReportingEngine engine = new ReportingEngine();
            
            // Execute the build report.
            engine.BuildReport(doc, contracts, "contracts");

            dataDir = dataDir + "BubbleChart Out.docx";

            // Save the finished document to disk.
            doc.Save(dataDir);

            Console.WriteLine("\nBubble chart template document is populated with the data about contracts.\nFile saved at " + dataDir);

        }
    }
}
