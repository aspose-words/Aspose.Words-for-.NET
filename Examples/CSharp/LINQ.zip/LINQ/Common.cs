﻿//////////////////////////////////////////////////////////////////////////
// Copyright 2001-2014 Aspose Pty Ltd. All Rights Reserved.
//
// This file is part of Aspose.Words. The source code in this file
// is only intended as a supplement to the documentation, and is provided
// "as is", without warranty of any kind, either expressed or implied.
//////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSharp.LINQ
{
    class Common
    {        
        public static IEnumerable<Client> GetClients()
        {
            foreach (Manager manager in GetManagers())
            {
                foreach (Contract contract in manager.Contracts)
                    yield return contract.Client;
            }          
        }
        private static IEnumerable<Manager> GetManagers()
        {
            Manager manager = new Manager { Name = "John Smith", Age = 37 };
            manager.Contracts = new Contract[]
            {
                new Contract { Client = new Client { Name = "A Company" }, Manager = manager, Price = 1200000, Date = new DateTime(2015, 1, 1) }, 
                new Contract { Client = new Client { Name = "B Ltd." }, Manager = manager, Price = 750000, Date = new DateTime(2015, 4, 1) }, 
                new Contract { Client = new Client { Name = "C & D" }, Manager = manager, Price = 350000, Date = new DateTime(2015, 7, 1) } 
            };
            yield return manager;

            manager = new Manager { Name = "Tony Anderson", Age = 37 };
            manager.Contracts = new Contract[]
            {
                new Contract { Client = new Client { Name = "E Corp." }, Manager = manager, Price = 650000, Date = new DateTime(2015, 2, 1) }, 
                new Contract { Client = new Client { Name = "F & Partners" }, Manager = manager, Price = 550000, Date = new DateTime(2015, 8, 1) }, 
            };
            yield return manager;

            manager = new Manager { Name = "July James", Age = 37 };
            manager.Contracts = new Contract[]
            {
                new Contract { Client = new Client { Name = "G & Co." }, Manager = manager, Price = 350000, Date = new DateTime(2015, 2, 1) }, 
                new Contract { Client = new Client { Name = "H Group" }, Manager = manager, Price = 250000, Date = new DateTime(2015, 5, 1) }, 
                new Contract { Client = new Client { Name = "I & Sons" }, Manager = manager, Price = 100000, Date = new DateTime(2015, 7, 1) },
                new Contract { Client = new Client { Name = "J Ent." }, Manager = manager, Price = 100000, Date = new DateTime(2015, 8, 1) } 
            };
            yield return manager;
        }
        public static Managers Managers()
        {
            // Create an instance of Managers class. Managers, an enumeration of instances of the Manager class
            Managers managers = new Managers();

            Manager manager;

            // Call JSManager. This method create John Smith manager and return it's reference.
            manager = JSManager();
            manager.Contracts = JSContracts();
            managers.Add(manager);

            // Call TAManager. This method create Tony Anderson manager and return it's reference.
            manager = TAManager();
            manager.Contracts = TAContracts();
            managers.Add(manager);

            // Call JJManager. This method create July James manager and return it's reference.
            manager = JJManager();
            manager.Contracts = JJContracts();
            managers.Add(manager);

            return managers;
        } 
        private static Manager JSManager()
        {
            Manager manager = new Manager("John Smith", 36, Photo());           
            return manager;
        }      
        private static Manager TAManager()
        {
            Manager manager = new Manager("Tony Anderson", 37, Photo());
            return manager;
        }         
        private static Manager JJManager()
        {
            Manager manager = new Manager("July James", 38, Photo());
            return manager;
        }
        private static byte[] Photo()
        {
            // The path to the documents directory.
            string dataDir = RunExamples.GetDataDir_LINQ();

            // Load the photo and read all bytes.
            byte[] imgdata = System.IO.File.ReadAllBytes(dataDir + "photo.png");
            return imgdata;
        }
        private static Contracts JSContracts()
        {
            // Create an instance of Contracts class. Contracts, an enumeration of instances of the Contract class. 
            Contracts contracts = new Contracts();

            // Create John Smith contract clients
            contracts.Add(new Contract(CreateClient("A Company"), 1200000,  new DateTime(2015, 1, 1)));
            contracts.Add(new Contract(CreateClient("B Ltd."), 750000, new DateTime(2015, 4, 1)));
            contracts.Add(new Contract(CreateClient("C & D"), 350000, new DateTime(2015, 7, 1)));
            return contracts;
        }
        private static Contracts TAContracts()
        {
            // // Create an instance of Contracts class. Contracts, an enumeration of instances of the Contract class. 
            Contracts contracts = new Contracts();

            // Create Tony Anderson contract clients
            contracts.Add(new Contract(CreateClient("E Corp."), 650000, new DateTime(2015, 2, 1)));
            contracts.Add(new Contract(CreateClient("F & Partners"), 550000, new DateTime(2015, 8, 1)));
            return contracts;
        }
        private static Contracts JJContracts()
        {
            // Create an instance of Contracts class. Contracts, an enumeration of instances of the Contract class. 
            Contracts contracts = new Contracts(); ;

            // Create July James contract clients
            contracts.Add(new Contract(CreateClient("G & Co."), 350000, new DateTime(2015, 2, 1)));
            contracts.Add(new Contract(CreateClient("H Group"), 250000, new DateTime(2015, 5, 1)));
            contracts.Add(new Contract(CreateClient("I & Sons"), 100000, new DateTime(2015, 7, 1)));
            contracts.Add(new Contract(CreateClient("J Ent."), 100000, new DateTime(2015, 8, 1)));
            return contracts;
        }
        public static Contracts Contracts()
        {
            Manager manager;

            // Create an instance of Contracts. Contracts, an enumeration of instances of the Contract class. 
            Contracts contracts = new Contracts();

            manager = JSManager();
            foreach (Contract contract in JSContracts())
            {
                contract.Manager = manager;
                contracts.Add(contract);
            }

            manager = TAManager();
            foreach (Contract contract in TAContracts())
            {
                contract.Manager = manager;
                contracts.Add(contract);
            }

            manager = JJManager();
            foreach (Contract contract in JJContracts())
            {
                contract.Manager = manager;
                contracts.Add(contract);
            }
            
            return contracts;
        }
        private static Client CreateClient(string name)
        {
          return  new Client(name);
        }       

    }
}
