﻿//////////////////////////////////////////////////////////////////////////
// Copyright 2001-2014 Aspose Pty Ltd. All Rights Reserved.
//
// This file is part of Aspose.Words. The source code in this file
// is only intended as a supplement to the documentation, and is provided
// "as is", without warranty of any kind, either expressed or implied.
//////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;

namespace CSharp.LINQ
{
    public class Manager
    {
        public Manager(String name, int age, byte[] photo)
        {
            _name = name;
            _age = age;
            _photo = photo;
        }
        public Manager(String name)
        {
            _name = name;
        }
        public String Name
        {
            get { return _name; }
        }
        public int Age
        {
            get { return _age; }
        }
        public byte[] Photo
        {
            get { return _photo; }
        }
        public Contracts Contracts
        {
            get { return _contracts; }
            set { _contracts = value; }
        }
        private String _name;       
        private int _age;
        private byte[] _photo;
        private Contracts _contracts;

    }
   
}
